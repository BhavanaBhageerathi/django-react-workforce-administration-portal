
function Dashboard() {
  
  return (
    <>
      <h2>Dashboard</h2>
      <p>Dashboard loaded!!</p>
      <div className="alert alert-success">You are logged in!</div>
    </>
  );
}

export default Dashboard;