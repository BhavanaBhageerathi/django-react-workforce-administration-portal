import {getDepartments} from "../services/departmentService";
import {useState,useEffect} from "react";

function DepartmentList(){
    // declare usestate variables to store dept list,loading status,error
    const[departments,setDepartments]=useState([]);
    const[loading,setLoading]=useState(true);
    const[error,setError]=useState("");

    // declare a function to get the list of depts by assynchronously calling the getDepartments() fn from departmentService
    const loadDepartments=async ()=>{
        try{
            const response=await getDepartments();
            setDepartments(response.data)
        }catch{
            setError("unable to load departments!")
        }finally{
            setLoading(false);
        }

    };

    //use the useEffect() hook with blank dependent array[]
    //to run the loadDepartments() fn only once the page loads

    useEffect(()=>{
        loadDepartments();
    },[]);


    return(
        <>
            <h2>Departments</h2>
            {loading && <div className="alert alert-info">Loading..</div>}
            {error && <div className="alert alert-danger">{error}</div>}
            <pre>{JSON.stringify(departments)}</pre>
        </>
    );
}
export default DepartmentList;