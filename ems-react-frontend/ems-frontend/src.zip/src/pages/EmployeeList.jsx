function EmployeeList(){
    return(
        <>
            <h2>EmployeeList</h2>
            <p>EmployeeList loaded!</p>
        </>
    );
}
export default EmployeeList;