//import our reusable api axios instance from api.js
import api from "./api";

//using this file,we are creating a service layer for our department entity

/*fn to get all departments*/
export const getDepartments = ()=>{
    return api.get("departments/");
};
